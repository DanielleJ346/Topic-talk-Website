-- =============================================================
-- FileName: Create_Database_And_Tables.sql
-- Programmer: Danielle Jae Ormerod
-- Description: This file will create the database and tables with the necessary constraints.
-- =============================================================

-- Drop the database if it exists
DROP DATABASE IF EXISTS topic_talk;
-- Create the database
CREATE DATABASE topic_talk;

-- Use the new database
USE topic_talk;

-- Create tables for the database

-- Users table
-- This table manages Users accounts.
CREATE TABLE UserAccount (
    userID INT AUTO_INCREMENT PRIMARY KEY,
    userName VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    userPassword VARCHAR(100) NOT NULL
);

-- Topic table
-- This table stores information about the topics users make.
CREATE TABLE Topic (
    topicID INT AUTO_INCREMENT PRIMARY KEY,
    topicTitle VARCHAR(255) NOT NULL,
    topicDesc TEXT,
    userID INT,
    FOREIGN KEY (userID) REFERENCES UserAccount(userID)
);

-- Comment table
-- This table stores comments made by users on topics.
CREATE TABLE Comment (
    commentID INT AUTO_INCREMENT PRIMARY KEY,
    topicID INT,
    userID INT,
    commentText TEXT,
    FOREIGN KEY (topicID) REFERENCES Topic(topicID),
    FOREIGN KEY (userID) REFERENCES UserAccount(userID)
);

-- Reply table
-- This table stores replies made on comments.
CREATE TABLE Reply (
    replyID INT AUTO_INCREMENT PRIMARY KEY,
    commentID INT,
    userID INT,
    replyText TEXT,
    FOREIGN KEY (commentID) REFERENCES Comment(commentID),
    FOREIGN KEY (userID) REFERENCES UserAccount(userID)
);


ALTER TABLE Topic
ADD topicSub TEXT,
ADD topicPic VARCHAR(255);

ALTER TABLE UserAccount
ADD userPic VARCHAR(255);