-- ===================================================================
-- FileName: Sample_Data_Inserts.sql
-- Programmer: Danielle Jae Ormerod
-- Description: This file will insert sample data into the database.
-- ===================================================================

USE topic_talk;

-- Insert sample data into the UserAccount table
INSERT INTO UserAccount (userName, email, userPassword, userPic)
VALUES
    ('Maximarex', 'max@gmail.com', 'MaximusRex', 'C:\Users\User\Documents\College textbooks\Advanced Java\Practice Java project\images\icons8-contacts-64'),
    ('BigSkinnySnake', 'snake@gmail.com', 'Snake123', 'C:\Users\User\Documents\College textbooks\Advanced Java\Practice Java project\images\icons8-contacts-64'),
    ('DisguisedBadger', 'badger@gmail.com', 'Disguised321', 'C:\Users\User\Documents\College textbooks\Advanced Java\Practice Java project\images\icons8-contacts-64'),
    ('FredicaRedHips', 'redhips@gmail.com', 'Fredica_123', 'C:\Users\User\Documents\College textbooks\Advanced Java\Practice Java project\images\icons8-contacts-64'),
    ('SquatElbowsOMG', 'omgelbows@gmail.com', 'squatOmg12', 'C:\Users\User\Documents\College textbooks\Advanced Java\Practice Java project\images\icons8-contacts-64'),
    ('UberDownToEarthPigeon', 'earth@gmail.com', 'earthPidgeon356', 'C:\Users\User\Documents\College textbooks\Advanced Java\Practice Java project\images\icons8-contacts-64'),
    ('iHasEars', 'ears123@gmail.com', 'iHasEars12', 'C:\Users\User\Documents\College textbooks\Advanced Java\Practice Java project\images\icons8-contacts-64'),
    ('MindOfAnthony', 'anthony@gmail.com', 'mindOf123', 'C:\Users\User\Documents\College textbooks\Advanced Java\Practice Java project\images\icons8-contacts-64'),
    ('GreedyInsides', 'insides@gmail.com', 'Greedy123', 'C:\Users\User\Documents\College textbooks\Advanced Java\Practice Java project\images\icons8-contacts-64'),
    ('BearGirl', 'beargirl@gmail.com', 'BearGirl123', 'C:\Users\User\Documents\College textbooks\Advanced Java\Practice Java project\images\icons8-contacts-64');
    
    -- Sample data for Topic table
INSERT INTO Topic (topicTitle, topicSub, topicDesc, userID, topicPic)
VALUES
	    ('Favourite Movies',
        'What movies do you never get tired of watching?',
        'Share your favorite movies that you can watch over and over again without getting bored. Whether it\'s a classic, a recent release, or a hidden gem, let us know what makes these movies special to you.',
        1,
        'C:\Users\User\eclipse-workspace\topic_talk\src\main\webapp\WEB-INF\images\movies.jpg'),
        ('Best Ways to Relax After a Long Day',
        'How do you unwind?',
        'After a busy day, everyone has their go-to methods for relaxation. Whether it\'s reading a book, taking a bath, or watching your favorite TV show, share your tips and routines for unwinding.',
        2,
        'C:\Users\User\eclipse-workspace\topic_talk\src\main\webapp\WEB-INF\images\relax.jpg'),
        ('Simple and Delicious Recipes',
        'What\'s your go-to easy meal?',
        'Cooking doesn\'t always have to be complicated. Share your favorite simple recipes that are quick to make and always turn out delicious. Perfect for busy weeknights or lazy weekends.',
        3,
        'C:\Users\User\eclipse-workspace\topic_talk\src\main\webapp\WEB-INF\images\meal.jpg'),
        ('Morning Routines',
        'How do you start your day?',
        'A good morning routine can set the tone for the rest of your day. Whether you wake up early for a workout, meditate, or savor your morning coffee, share how you like to start your mornings.',
        4,
        '"C:\Users\User\eclipse-workspace\topic_talk\src\main\webapp\WEB-INF\images\routine.jpg"'),
        ('Favorite Books of All Time',
        'Which books have left a lasting impact on you?',
        'Books have the power to change our perspectives and stay with us for years. What are the books that have influenced you the most, and why? Share your all-time favorite reads.',
        5,
        'C:\Users\User\eclipse-workspace\topic_talk\src\main\webapp\WEB-INF\images\book.jpg'),
        ('Best Budget Travel Destinations',
        'Affordable adventures around the world',
        'Traveling doesn\'t have to break the bank. Share your favorite budget-friendly travel destinations and tips for exploring the world without spending a fortune.',
        6,
        'C:\Users\User\eclipse-workspace\topic_talk\src\main\webapp\WEB-INF\images\travel.jpg'),
        ('How Do You Stay Motivated?',
        'Tips for keeping the drive alive',
        'Staying motivated can be a challenge, especially when working on long-term goals. How do you keep yourself motivated? Share your strategies for staying focused and energized.',
        7,
        'C:\Users\User\eclipse-workspace\topic_talk\src\main\webapp\WEB-INF\images\motivated.jpg'),
        ('Pet Care Tips',
        'How do you take care of your furry friends?',
        'Pets are part of the family, and taking care of them is a big responsibility. Whether you have dogs, cats, or something more exotic, share your best pet care tips and tricks.',
        8,
        'C:\Users\User\eclipse-workspace\topic_talk\src\main\webapp\WEB-INF\images\pet.jpg'),
        ('Simple DIY Projects',
        'Easy and fun crafts you can do at home',
        'Looking for a creative outlet? Share your favorite DIY projects that anyone can do at home. Whether it\'s home decor, crafting, or upcycling, let\'s inspire each other to get crafty.',
        9,
        'C:\Users\User\eclipse-workspace\topic_talk\src\main\webapp\WEB-INF\images\DIY.jpg');
      
      -- Sample data for Comment table
INSERT INTO Comment (topicID, userID, commentText)
VALUES
	    (1, 5,
        'For me, it\'s The Shawshank Redemption. The storytelling is just so powerful, and the ending gets me every time.'),
        (2, 6,
        'I love to unwind by taking a long walk in the park with my dog. It\'s a great way to clear my mind and get some fresh air'),
        (3, 7,
        'One of my favorites is a quick stir-fry with veggies, chicken, and a teriyaki sauce. It\'s ready in 15 minutes and tastes amazing!'),
        (4, 8,
        'I start my day with 10 minutes of meditation followed by a cup of green tea. It really helps me feel centered before the day begins.'),
        (5, 9,
        'One book that really stuck with me is To Kill a Mockingbird. Its themes of justice and morality are so powerful and still relevant today.'),
        (6, 10, 
        'I had an amazing trip to Lisbon, Portugal. The food was incredible, the scenery was beautiful, and it was surprisingly affordable!'),
        (7, 1,
        'I set small, achievable goals each week and reward myself when I reach them. It keeps me moving forward and feeling accomplished.'),
        (8, 2,
        'For my cat, regular grooming is key to keeping her coat healthy and reducing shedding. She loves it when I brush her!'),
        (9, 3,
        'I recently made a set of coasters out of old magazines. It was super easy and they turned out great!');
        
        -- Sample data for Reply table
INSERT INTO Reply (commentID, userID, replyText)
VALUES
	    (1, 2,
        'I love that movie too!'),
        (2, 5,
        'What dog breed do you have?'),
        (3, 3,
        'Can you put the recipe down below?'),
        (4, 6,
        'What meditation guide do you follow?'),
        (5, 7,
        'Cab I order this book online?'),
        (6, 9,
        'I visited Portugal last year to visit family!'),
        (7, 10,
        'I always reward myself with a chocloate after having a good study session'),
        (8, 1,
        'My cat always bites the brush if i try this!'),
        (9, 8,
        'Magazines? How did you do that?');