package model;

import java.util.ArrayList;
import java.util.List;

//import model.Comment;

/**
 * Represents a topic in the TopicTalk application.
 * A topic is created by a user and can have multiple comments associated with it.
 */
public class Topic {
    
    private int id; // The unique ID of the topic
    private int userID; // The ID of the user who created the topic
    private String topicTitle; // The title of the topic
    private String topicDesc; // The description of the topic
    private String topicPic; // The file path to the image associated with the topic
	private List<Comment> comments; // The list of comments associated with this topic
	private String authorName; // The name of the author who created the topic

    // Default constructor for creating an empty Topic object.
    public Topic() {
    }

    /**
     * Parameterized constructor for creating a Topic object with specified values.
     *
     * @param id The unique ID of the topic
     * @param userID The ID of the user who created the topic
     * @param topicTitle The title of the topic
     * @param topicDesc The description of the topic
     * @param topicPic The file path to the image associated with the topic
     */
    public Topic(int id, int userID, String topicTitle, String topicDesc, String topicPic) {
        this.id = id;
        this.userID = userID;
        this.topicTitle = topicTitle;
        this.topicDesc = topicDesc;
        this.topicPic = topicPic;
    }

    /**
     * Gets the unique ID of the topic.
     *
     * @return The topic ID.
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the unique ID of the topic.
     *
     * @param id The topic ID.
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Gets the ID of the user who created the topic.
     *
     * @return The user ID.
     */
    public int getUserID() {
        return userID;
    }

    /**
     * Sets the ID of the user who created the topic.
     *
     * @param userID The user ID.
     */
    public void setUserID(int userID) {
        this.userID = userID;
    }

    /**
     * Gets the title of the topic.
     *
     * @return The topic title.
     */
    public String getTopicTitle() {
        return topicTitle;
    }

    /**
     * Sets the title of the topic.
     *
     * @param topicTitle The topic title.
     */
    public void setTopicTitle(String topicTitle) {
        this.topicTitle = topicTitle;
    }

    /**
     * Gets the description of the topic.
     *
     * @return The topic description.
     */
    public String getTopicDesc() {
        return topicDesc;
    }

    /**
     * Sets the description of the topic.
     *
     * @param topicDesc The topic description.
     */
    public void setTopicDesc(String topicDesc) {
        this.topicDesc = topicDesc;
    }

    /**
     * Gets the file path to the image associated with the topic.
     *
     * @return The image path.
     */
    public String getTopicPic() {
        return topicPic;
    }

    /**
     * Sets the file path to the image associated with the topic.
     *
     * @param topicPic The image path.
     */
    public void setTopicPic(String topicPic) {
        this.topicPic = topicPic;
    }

    /**
     * Gets the name of the author who created the topic.
     *
     * @return The author name.
     */
    public String getAuthorName() {
        return authorName;
    }

    /**
     * Sets the name of the author who created the topic.
     *
     * @param authorName The author name.
     */
    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    /**
     * Gets the list of comments associated with this topic.
     *
     * @return The list of comments.
     */
    public List<Comment> getComments() {
        return comments;
    }

    /**
     * Sets the list of comments associated with this topic.
     *
     * @param comments The list of comments.
     */
    public void setComments(List<Comment> comments) {
        this.comments = comments;
    }

    /**
     * Adds a comment to the list of comments associated with this topic.
     *
     * @param comment The Comment object to be added.
     */
    public void addComment(Comment comment) {
        if (comments == null) {
            comments = new ArrayList<>();
        }
        comments.add(comment);
    }

    /**
     * Removes a comment from the list of comments associated with this topic by its ID.
     *
     * @param commentId The ID of the comment to be removed.
     */
    public void removeCommentById(int commentId) {
        if (comments != null) {
            comments.removeIf(comment -> comment.getTopicID() == commentId);
        }
    }

    /**
     * Returns a string representation of the Topic object, useful for debugging and logging.
     *
     * @return A string containing the topic's ID, user ID, title, description, and image path.
     */
    @Override
    public String toString() {
        return "Topic{" +
                "id=" + id +
                ", userID=" + userID +
                ", title='" + topicTitle + '\'' +
                ", description='" + topicDesc + '\'' +
                ", imagePath='" + topicPic + '\'' +
                ", authorName='" + authorName + '\'' +
                ", comments=" + comments +
                '}';
    }

}
