package model;

/**
 * Represents a User in the TopicTalk application.
 * This class holds the details related to a user.
 */
public class User {
    private int id; // The unique ID of the user.
    private String username; // The username chosen by the user.
    private String email; // The email address of the user. 
    private String password; // The password for the user's account.
    private String role; // The role of the user (e.g., admin, regular user).
    private String status; // The status of the user (e.g., active, inactive). 
    private String profilePic; // The URL or path of the user's profile picture.

    /**
     * Default constructor.
     */
    public User() {
    }

    /**
     * Parameterized constructor.
     *
     * @param id The unique ID of the user.
     * @param username The username chosen by the user.
     * @param email The email address of the user.
     * @param password The password for the user's account.
     * @param role The role of the user.
     * @param status The status of the user.
     * @param profilePic The URL or path of the user's profile picture.
     */
    public User(int id, String username, String email, String password, String role, String status, String profilePic) {
        this.id = id;
        this.username = username;
        this.email = email;
        this.password = password;
        this.role = role;
        this.status = status;
        this.profilePic = profilePic;
    }

    /**
     * Gets the unique ID of the user.
     *
     * @return The user's ID.
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the unique ID of the user.
     *
     * @param id The user's ID.
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Gets the username of the user.
     *
     * @return The user's username.
     */
    public String getUsername() {
        return username;
    }

    /**
     * Sets the username of the user.
     *
     * @param username The user's username.
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * Gets the email address of the user.
     *
     * @return The user's email address.
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the email address of the user.
     *
     * @param email The user's email address.
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Gets the password of the user.
     *
     * @return The user's password.
     */
    public String getPassword() {
        return password;
    }

    /**
     * Sets the password of the user.
     *
     * @param password The user's password.
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Gets the role of the user.
     *
     * @return The user's role.
     */
    public String getRole() {
        return role;
    }

    /**
     * Sets the role of the user.
     *
     * @param role The user's role.
     */
    public void setRole(String role) {
        this.role = role;
    }

    /**
     * Gets the status of the user.
     *
     * @return The user's status.
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the status of the user.
     *
     * @param status The user's status.
     */
    public void setStatus(String status) {
        this.status = status;
    }
    
    /**
     * Gets the profile picture URL or path of the user.
     *
     * @return The user's profile picture URL or path.
     */
    public String getProfilePic() {
        return profilePic;
    }

    /**
     * Sets the profile picture URL or path of the user.
     *
     * @param profilePic The user's profile picture URL or path.
     */
    public void setProfilePic(String profilePic) {
        this.profilePic = profilePic;
    }

    /**
     * Provides a string representation of the user.
     *
     * @return A string containing the user's details.
     */
    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", email='" + email + '\'' +
                ", role='" + role + '\'' +
                ", status='" + status + '\'' +
                ", profilePic='" + profilePic + '\'' +
                '}';
    }
}
