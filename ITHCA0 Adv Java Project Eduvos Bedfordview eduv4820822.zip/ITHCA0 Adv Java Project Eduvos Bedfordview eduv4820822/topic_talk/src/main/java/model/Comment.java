package model;

import java.util.List;

/**
 * Represents a comment in the TopicTalk application.
 * Each comment is associated with a topic and is created by a user.
 */
public class Comment {
	private int commentID; // The unique identifier for the comment
    private int topicID; // The ID of the topic to which this comment is associated
    private int userID; // The ID of the user who made the comment
    private String commentText; // The content of the comment
    
    private List<Reply> replies; // The list of replies associated with this comment
    //private String commenterName; // The name of the user who made the comment

    /**
     * Gets the unique identifier for the comment.
     *
     * @return The comment ID.
     */
    public int getCommentID() {
        return commentID;
    }

    /**
     * Sets the unique identifier for the comment.
     *
     * @param id The comment ID.
     */
    public void setCommentID(int commentID) {
        this.commentID = commentID;
    }
    
    /**
     * Gets the ID of the topic to which this comment is associated.
     *
     * @return The topic ID.
     */
    public int getTopicID() {
        return topicID;
    }

    /**
     * Sets the ID of the topic to which this comment is associated.
     *
     * @param topicID The topic ID.
     */
    public void setTopicID(int topicID) {
        this.topicID = topicID;
    }

    /**
     * Gets the ID of the user who made the comment.
     *
     * @return The user ID.
     */
    public int getUserID() {
        return userID;
    }

    /**
     * Sets the ID of the user who made the comment.
     *
     * @param userID The user ID.
     */
    public void setUserID(int userID) {
        this.userID = userID;
    }

    /**
     * Gets the content of the comment.
     *
     * @return The comment text.
     */
    public String getCommentText() {
        return commentText;
    }

    /**
     * Sets the content of the comment.
     *
     * @param commentText The comment text.
     */
    public void setCommentText(String commentText) {
        this.commentText = commentText;
    }
    
    /**
     * Gets the list of replies associated with this comment.
     *
     * @return The list of replies.
     */
    public List<Reply> getReplies() {
        return replies;
    }

    /**
     * Sets the list of replies associated with this comment.
     *
     * @param replies The list of replies.
     */
    public void setReplies(List<Reply> replies) {
        this.replies = replies;
    }

    /**
     * Sets the content of the comment. 
     * This method can be used interchangeably with setCommentText.
     *
     * @param commentContent The content of the comment.
     */
    public void setContent(String commentContent) {
        this.commentText = commentContent;
    }
}

