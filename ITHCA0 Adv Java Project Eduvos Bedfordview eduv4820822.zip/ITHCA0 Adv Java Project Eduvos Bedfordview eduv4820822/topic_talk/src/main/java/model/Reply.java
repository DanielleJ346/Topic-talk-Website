package model;

/**
 * Represents a reply to a comment in the TopicTalk application.
 * Each reply is associated with a comment and is created by a user.
 */

public class Reply {
    private String replyText; // The content of the reply
    private String replierName; // The name of the user who made the reply
    private int commentID; // The ID of the comment to which this reply is associated
    private int userID; // The ID of the user who made the reply

    /**
     * Gets the content of the reply.
     *
     * @return The reply text.
     */
    public String getReplyText() {
        return replyText;
    }

    /**
     * Sets the content of the reply.
     *
     * @param replyText The reply text.
     */
    public void setReplyText(String replyText) {
        this.replyText = replyText;
    }

    /**
     * Gets the name of the user who made the reply.
     *
     * @return The replier's name.
     */
    public String getReplierName() {
        return replierName;
    }

    /**
     * Sets the name of the user who made the reply.
     *
     * @param replierName The replier's name.
     */
    public void setReplierName(String replierName) {
        this.replierName = replierName;
    }

    /**
     * Gets the ID of the comment to which this reply is associated.
     *
     * @return The comment ID.
     */
    public int getCommentID() {
        return commentID;
    }

    /**
     * Sets the ID of the comment to which this reply is associated.
     *
     * @param commentID The comment ID.
     */
    public void setCommentID(int commentID) {
        this.commentID = commentID;
    }

    /**
     * Gets the ID of the user who made the reply.
     *
     * @return The user ID.
     */
    public int getUserID() {
        return userID;
    }

    /**
     * Sets the ID of the user who made the reply.
     *
     * @param userID The user ID.
     */
    public void setUserID(int userID) {
        this.userID = userID;
    }

    /**
     * Sets the content of the reply.
     * This method can be used interchangeably with setReplyText.
     *
     * @param replyContent The content of the reply.
     */
    public void setContent(String replyContent) {
        this.replyText = replyContent;
    }
}

