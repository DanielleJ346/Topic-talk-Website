package controller;

import java.io.IOException; 
import java.sql.Connection; 
import java.sql.PreparedStatement; 
import java.sql.SQLException; 
import javax.servlet.ServletException; 
import javax.servlet.annotation.WebServlet; 
import javax.servlet.http.HttpServlet; 
import javax.servlet.http.HttpServletRequest; 
import javax.servlet.http.HttpServletResponse; 

import topictalk.util.DatabaseConnection; // Import custom utility class for initializing database connections

/**
 * Servlet implementation class RegisterUserServlet
 * This servlet handles user registration by inserting user details into the database.
 */
@WebServlet("/RegisterUserServlet") // Define the URL pattern for the servlet
public class RegisterUserServlet extends HttpServlet {
    private static final long serialVersionUID = 1L; // Serial version UID for serialization
       
    /**
     * Default constructor for RegisterUserServlet.
     */
    public RegisterUserServlet() {
        super();
        // Default constructor
    }

    /**
     * Handles POST requests for registering a new user.
     * This method retrieves user data from the request, hashes the password, and inserts the data into the database.
     *
     * @param request  The HttpServletRequest object that contains the request the client made to the servlet.
     * @param response The HttpServletResponse object that contains the response the servlet returns to the client.
     * @throws ServletException If a servlet-specific error occurs.
     * @throws IOException      If an I/O error occurs.
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get form parameters from the registration form
        String userName = request.getParameter("username");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Hash the password (ideally using a secure hashing algorithm like BCrypt)
        String hashedPassword = password;  // Ideally, hash the password here

        // Database connection and insertion logic
        try (Connection conn = DatabaseConnection.initializeDatabase()) {
            // Prepare an SQL query to insert the new user into the UserAccount table
            String query = "INSERT INTO UserAccount (userName, email, userPassword) VALUES (?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(query)) {
                pstmt.setString(1, userName); // Set the username parameter in the query
                pstmt.setString(2, email); // Set the email parameter in the query
                pstmt.setString(3, hashedPassword); // Set the hashed password parameter in the query

                // Execute the query to insert the new user
                pstmt.executeUpdate();
            }

            // Redirect the user to the login page on successful registration
            response.sendRedirect("login.jsp?registration=success");

        } catch (SQLException | ClassNotFoundException e) {
            // Handle SQL or class not found exceptions and print the stack trace
            e.printStackTrace();
            // Redirect to the sign-up page with an error message if registration fails
            response.sendRedirect("signUp.jsp?error=registration_failed");
        }
    }

    /**
     * Handles GET requests.
     * This method could be used to serve a registration page or handle other GET requests related to registration.
     *
     * @param request  The HttpServletRequest object that contains the request the client made to the servlet.
     * @param response The HttpServletResponse object that contains the response the servlet returns to the client.
     * @throws ServletException If a servlet-specific error occurs.
     * @throws IOException      If an I/O error occurs.
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Handle GET requests, if needed
        response.getWriter().append("Served at: ").append(request.getContextPath());
    }
}
