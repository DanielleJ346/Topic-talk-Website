package controller;

import java.io.IOException; // Import IOException for handling input/output exceptions
import java.sql.Connection; // Import Connection to manage database connections
import java.sql.PreparedStatement; // Import PreparedStatement to execute SQL queries
import java.sql.ResultSet; // Import ResultSet to store the result of a SQL query
import java.util.ArrayList; // Import ArrayList for dynamic array-like data structure
import java.util.List; // Import List for using the List interface
import javax.servlet.ServletException; // Import ServletException for handling servlet-specific exceptions
import javax.servlet.annotation.WebServlet; // Import WebServlet for servlet annotation
import javax.servlet.http.HttpServlet; // Import HttpServlet for handling HTTP requests
import javax.servlet.http.HttpServletRequest; // Import HttpServletRequest for handling request data
import javax.servlet.http.HttpServletResponse; // Import HttpServletResponse for sending responses

import model.Comment; // Import Comment model
import model.Topic; // Import Topic model
import dao.CommentDAO; // Import CommentDAO for database operations related to comments
import topictalk.util.DatabaseConnection; // Import DatabaseConnection utility to establish database connections

/**
 * Servlet implementation class ViewTopicsServlet
 * Handles the retrieval and display of topics and their associated comments.
 */
@WebServlet("/ViewTopicsServlet") // Define the URL pattern for the servlet
public class ViewTopicsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L; // Serial version UID for serialization

    /**
     * Default constructor.
     */
    public ViewTopicsServlet() {
        super(); // Call the superclass constructor
    }

    /**
     * Handles the GET request to retrieve and display topics with their comments.
     *
     * @param request  The HttpServletRequest object that contains the request the client made to the servlet.
     * @param response The HttpServletResponse object that contains the response the servlet returns to the client.
     * @throws ServletException If a servlet-specific error occurs.
     * @throws IOException      If an I/O error occurs.
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try (Connection conn = DatabaseConnection.initializeDatabase()) { // Initialize the database connection

            // SQL query to retrieve topics with author names by joining topic and user tables
            String query = "SELECT t.id as topicId, t.topicTitle, t.topicDesc, u.name as authorName FROM topic t " +
                           "JOIN user u ON t.userID = u.id";
            PreparedStatement pstmt = conn.prepareStatement(query); // Prepare the SQL query
            ResultSet rs = pstmt.executeQuery(); // Execute the query and get the result set

            List<Topic> topics = new ArrayList<>(); // Initialize an empty list to store topics
            while (rs.next()) { // Loop through the result set
                Topic topic = new Topic(); // Create a new Topic object
                topic.setId(rs.getInt("topicId")); // Set the topic ID
                topic.setTopicTitle(rs.getString("topicTitle")); // Set the topic title
                topic.setTopicDesc(rs.getString("topicDesc")); // Set the topic description
                topic.setAuthorName(rs.getString("authorName")); // Set the author's name

                // Retrieve comments associated with the current topic using CommentDAO
                CommentDAO commentDAO = new CommentDAO();
                List<Comment> comments = commentDAO.getCommentsByTopicID(rs.getInt("topicId")); // Get comments by topic ID
                topic.setComments(comments); // Set the comments for the topic

                topics.add(topic); // Add the topic to the list
            }

            // Set the list of topics as a request attribute and forward to the JSP
            request.setAttribute("topics", topics);
            request.getRequestDispatcher("viewTopics.jsp").forward(request, response); // Forward the request to viewTopics.jsp

        } catch (Exception e) { // Handle any exceptions that occur during database operations
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "An error occurred while retrieving topics."); // Send an error response
        }
    }

    /**
     * Handles the POST request by forwarding it to the GET request handler.
     *
     * @param request  The HttpServletRequest object that contains the request the client made to the servlet.
     * @param response The HttpServletResponse object that contains the response the servlet returns to the client.
     * @throws ServletException If a servlet-specific error occurs.
     * @throws IOException      If an I/O error occurs.
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Forward POST requests to the GET method for handling
        doGet(request, response);
    }
}
