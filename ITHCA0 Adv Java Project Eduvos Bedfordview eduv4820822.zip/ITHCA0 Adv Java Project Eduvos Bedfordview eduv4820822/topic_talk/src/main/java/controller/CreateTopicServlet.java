package controller;

import java.io.File; // Import the File class for handling file paths
import java.io.IOException; // Import IOException for handling input/output exceptions
import java.sql.SQLException; // Import SQLException for handling SQL-related exceptions

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import dao.TopicDAO; // Import TopicDAO for interacting with the topic database
import model.Topic; // Import Topic model class
import model.User; // Import User model class

@WebServlet("/CreateTopicServlet")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB: Sets the file size threshold for when files are written to disk
                 maxFileSize = 1024 * 1024 * 10,      // 10MB: Sets the maximum size allowed for uploaded files
                 maxRequestSize = 1024 * 1024 * 50)   // 50MB: Sets the maximum size allowed for a complete request
public class CreateTopicServlet extends HttpServlet {
    private static final long serialVersionUID = 1L; // Serial version UID for serialization

    public CreateTopicServlet() {
        super(); // Call the superclass constructor
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	// Get the current session and the logged-in user
    	HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");

        // If the user is not logged in, redirect to the login page
        if (currentUser == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        
        // Get the topic title and description from the request
        String title = request.getParameter("title");
        String description = request.getParameter("description");
        // Get the uploaded file part from the request
        Part filePart = request.getPart("image");
        String fileName = "";
        
        // If a file was uploaded, extract its file name and save it to the specified directory
        if (filePart != null && filePart.getSize() > 0) {
            fileName = extractFileName(filePart); // Extract the file name
            String savePath = "your-directory-path" + File.separator + fileName; // Set the save path
            filePart.write(savePath); // Save the file to the specified path
        }

     // Create a new Topic object and set its properties
        Topic topic = new Topic();
        topic.setTopicTitle(title); // Set the topic title
        topic.setTopicDesc(description); // Set the topic description
        topic.setTopicPic(fileName); // Set the topic image file name
        topic.setUserID(currentUser.getId()); // Set the user ID of the current user

        // Use TopicDAO to create the new topic in the database
        TopicDAO topicDAO = new TopicDAO();
        boolean isCreated = false;
        try {
            isCreated = topicDAO.createTopic(topic); // Attempt to create the topic in the database
        } catch (ClassNotFoundException e) {
            e.printStackTrace(); // Handle ClassNotFoundException
        } catch (SQLException e) {
            e.printStackTrace(); // Handle SQLException
        }

        // If the topic was successfully created, redirect to the topics page with a success message
        if (isCreated) {
            response.sendRedirect("topics.jsp?success=true");
        } else { // If there was an error, redirect back to the create topic page with an error message
            response.sendRedirect("createTopic.jsp?error=true");
        }
    }

    // Helper method to extract the file name from the content-disposition header
    private String extractFileName(Part part) {
        String contentDisposition = part.getHeader("content-disposition"); // Get the content-disposition header
        String[] items = contentDisposition.split(";"); // Split the header into its parts
        for (String item : items) {
            if (item.trim().startsWith("filename")) { // Find the part that starts with "filename"
                return item.substring(item.indexOf("=") + 2, item.length() - 1); // Extract and return the file name
            }
        }
        return ""; // Return an empty string if no file name was found
    }
}
