package controller;

import java.io.IOException; 
import java.sql.Connection; 
import java.sql.PreparedStatement; 
import java.sql.SQLException; 
import javax.servlet.ServletException; 
import javax.servlet.annotation.WebServlet; 
import javax.servlet.http.HttpServlet; 
import javax.servlet.http.HttpServletRequest; 
import javax.servlet.http.HttpServletResponse; 

import topictalk.util.DatabaseConnection; // Import custom utility class for initializing database connections

/**
 * Servlet implementation class ResetPasswordServlet
 * This servlet handles password reset requests by updating the user's password in the database.
 */
@WebServlet("/ResetPasswordServlet") // Define the URL pattern for the servlet
public class ResetPasswordServlet extends HttpServlet {
    private static final long serialVersionUID = 1L; // Serial version UID for serialization

    /**
     * Handles POST requests for resetting a user's password.
     * This method retrieves the form data, checks if the new passwords match, and updates the user's password in the database.
     *
     * @param request  The HttpServletRequest object that contains the request the client made to the servlet.
     * @param response The HttpServletResponse object that contains the response the servlet returns to the client.
     * @throws ServletException If a servlet-specific error occurs.
     * @throws IOException      If an I/O error occurs.
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form data from the password reset form
        String email = request.getParameter("email");
        String newPassword = request.getParameter("new_password");
        String confirmPassword = request.getParameter("confirm_password");

        // Check if the new password and confirm password match
        if (newPassword.equals(confirmPassword)) {
            // Hash the new password before storing it (this step should involve a secure hashing method)
            String hashedPassword = newPassword;  // Hash the password as per your security requirements

            Connection conn = null; // Declare Connection object
            PreparedStatement pstmt = null; // Declare PreparedStatement object

            try {
                // Initialize the database connection
                conn = DatabaseConnection.initializeDatabase();

                // SQL query to update the password for the user with the given email
                String query = "UPDATE UserAccount SET userPassword = ? WHERE email = ?";
                pstmt = conn.prepareStatement(query);
                pstmt.setString(1, hashedPassword); // Set the hashed password in the query
                pstmt.setString(2, email); // Set the email in the query

                // Execute the update query and check if any rows were affected
                int updatedRows = pstmt.executeUpdate();

                if (updatedRows > 0) {
                    // Password successfully updated, redirect the user to the login page with a success message
                    response.sendRedirect("login.jsp?reset_success=true");
                } else {
                    // Failed to update the password, redirect to the reset password page with an error message
                    response.sendRedirect("resetPassword.jsp?email=" + email + "&error=reset_failed");
                }
            } catch (SQLException | ClassNotFoundException e) {
                // Handle SQL or class not found exceptions and print the stack trace
                e.printStackTrace();
                // Redirect to the reset password page with an error message
                response.sendRedirect("resetPassword.jsp?email=" + email + "&error=reset_failed");
            } finally {
                // Clean up resources by closing the PreparedStatement and Connection objects
                try {
                    if (pstmt != null) pstmt.close();
                    if (conn != null) conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        } else {
            // Passwords do not match, redirect to the reset password page with an error message
            response.sendRedirect("resetPassword.jsp?email=" + email + "&error=password_mismatch");
        }
    }
}
