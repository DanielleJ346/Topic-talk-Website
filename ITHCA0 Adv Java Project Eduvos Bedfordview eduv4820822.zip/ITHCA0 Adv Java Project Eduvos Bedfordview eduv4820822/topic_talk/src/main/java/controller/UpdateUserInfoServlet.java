package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import topictalk.util.DatabaseConnection; // Import DatabaseConnection utility to establish database connections

/**
 * Servlet implementation class UpdateUserInfoServlet
 * This servlet handles updating the user's information in the database.
 */
@WebServlet("/UpdateUserInfoServlet") // Define the URL pattern for the servlet
public class UpdateUserInfoServlet extends HttpServlet {
    private static final long serialVersionUID = 1L; // Serial version UID for serialization

    /**
     * Handles POST requests to update user information.
     * 
     * @param request  The HttpServletRequest object that contains the request the client made to the servlet.
     * @param response The HttpServletResponse object that contains the response the servlet returns to the client.
     * @throws ServletException If a servlet-specific error occurs.
     * @throws IOException      If an I/O error occurs.
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Obtain session and user ID from the session object
        HttpSession session = request.getSession();
        int userId = (int) session.getAttribute("userId");
        
        // Retrieve form data from the request object
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        Connection conn = null; // Initialize the database connection object
        PreparedStatement pstmt = null; // Initialize the PreparedStatement object

        try {
            // Initialize the database connection
            conn = DatabaseConnection.initializeDatabase();

            // SQL query for updating user information in the Users table
            String updateQuery = "UPDATE Users SET name = ?, email = ?, password = ? WHERE id = ?";
            pstmt = conn.prepareStatement(updateQuery);
            pstmt.setString(1, name); // Set the name parameter in the query
            pstmt.setString(2, email); // Set the email parameter in the query
            pstmt.setString(3, password); // Set the password parameter in the query
            pstmt.setInt(4, userId); // Set the user ID parameter in the query

            // Execute the update query
            pstmt.executeUpdate();

            // Update session attributes with the new user information
            session.setAttribute("userName", name);
            session.setAttribute("userEmail", email);

            // Redirect to the profile page with a success message
            response.sendRedirect("userProfile.jsp?success=true");
        } catch (Exception e) {
            e.printStackTrace();
            // Redirect to the profile page with an error message if an exception occurs
            response.sendRedirect("userProfile.jsp?error=true");
        } finally {
            // Clean up resources by closing the PreparedStatement and Connection objects
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}

