package controller;

import dao.TopicDAO;
import model.Topic;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TopicServlet
 * This servlet handles requests for displaying a list of topics.
 */
@WebServlet("/topics") // Define the URL pattern for the servlet
public class TopicServlet extends HttpServlet {
    private static final long serialVersionUID = 1L; // Serial version UID for serialization

    /**
     * Handles GET requests to display a list of topics.
     * This method retrieves all topics from the database and forwards the data to the JSP page for rendering.
     *
     * @param request  The HttpServletRequest object that contains the request the client made to the servlet.
     * @param response The HttpServletResponse object that contains the response the servlet returns to the client.
     * @throws ServletException If a servlet-specific error occurs.
     * @throws IOException      If an I/O error occurs.
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Create an instance of TopicDAO to interact with the database
        TopicDAO topicDAO = new TopicDAO();
        
        // Retrieve all topics from the database
        List<Topic> topics = topicDAO.getAllTopics();
        
        // Set the retrieved topics as a request attribute
        request.setAttribute("topics", topics);
        
        // Forward the request and response objects to the topics.jsp page for rendering
        request.getRequestDispatcher("topics.jsp").forward(request, response);
    }
}
