package controller;

import java.io.IOException; 
import java.sql.Connection; 
import java.sql.PreparedStatement; 
import java.sql.ResultSet; 
import java.sql.SQLException; 
import javax.servlet.ServletException; 
import javax.servlet.annotation.WebServlet; 
import javax.servlet.http.HttpServlet; 
import javax.servlet.http.HttpServletRequest; 
import javax.servlet.http.HttpServletResponse; 
import javax.servlet.http.HttpSession; 

import topictalk.util.DatabaseConnection; // Import custom utility class for initializing database connections

/**
 * Servlet implementation class LoginUserServlet
 * This servlet handles the login functionality for users.
 */
@WebServlet("/LoginUserServlet") // Define the URL pattern for the servlet
public class LoginUserServlet extends HttpServlet {
    private static final long serialVersionUID = 1L; // Serial version UID for serialization

    /**
     * Default constructor for LoginUserServlet.
     */
    public LoginUserServlet() {
        super();
    }

    /**
     * Handles POST requests for logging in the user.
     * This method verifies the user's email and password, creates a session, and redirects the user accordingly.
     *
     * @param request  The HttpServletRequest object that contains the request the client made to the servlet.
     * @param response The HttpServletResponse object that contains the response the servlet returns to the client.
     * @throws ServletException If a servlet-specific error occurs.
     * @throws IOException      If an I/O error occurs.
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve the email and password parameters from the request
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Hash the password for comparison (ensure that the same hashing algorithm is used as during registration)
        String hashedPassword = password;  // Ideally, hash the password here before comparison

        try {
            // Initialize a connection to the database
            Connection conn = DatabaseConnection.initializeDatabase();

            // Prepare a SQL query to check if the email and hashed password match a user in the UserAccount table
            String query = "SELECT * FROM UserAccount WHERE email = ? AND userPassword = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, email); // Set the email parameter in the query
            pstmt.setString(2, hashedPassword); // Set the hashed password parameter in the query

            // Execute the query and store the result
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                // If the user exists, create a session and store user information
                HttpSession session = request.getSession();
                session.setAttribute("userName", rs.getString("userName")); // Store the user name in the session
                session.setAttribute("userID", rs.getInt("userID")); // Store the user ID in the session
                // Redirect the user to the topic page
                response.sendRedirect("topic.jsp");
            } else {
                // If the user doesn't exist, redirect back to the login page with an error message
                response.sendRedirect("login.jsp?error=invalid_credentials");
            }

            // Close the database connection
            conn.close();
        } catch (SQLException | ClassNotFoundException e) {
            // Handle SQL or class not found exceptions and print the stack trace
            e.printStackTrace();
            // Redirect to the login page with a general login failed error message
            response.sendRedirect("login.jsp?error=login_failed");
        }
    }

    /**
     * Handles GET requests by forwarding them to the doPost method.
     * This ensures that both GET and POST requests are processed the same way.
     *
     * @param request  The HttpServletRequest object that contains the request the client made to the servlet.
     * @param response The HttpServletResponse object that contains the response the servlet returns to the client.
     * @throws ServletException If a servlet-specific error occurs.
     * @throws IOException      If an I/O error occurs.
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Forward GET requests to the doPost method
        doPost(request, response);
    }
}
