package controller;

import dao.CommentDAO; // Import the DAO class for managing comments and replies
import dao.Reply; // Import the Reply model class

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet implementation class AddReplyServlet
 * Handles the addition of a reply to a specific comment.
 */
@WebServlet("/AddReplyServlet")
public class AddReplyServlet extends HttpServlet {
    private static final long serialVersionUID = 1L; // Serial version UID for serialization

    /**
     * Default constructor.
     */
    public AddReplyServlet() {
        super();
    }

    /**
     * Handles the GET request. Since adding a reply is a POST operation, this method returns an error message.
     * 
     * @param request  The HttpServletRequest object that contains the request the client made to the servlet.
     * @param response The HttpServletResponse object that contains the response the servlet returns to the client.
     * @throws ServletException If a servlet-specific error occurs.
     * @throws IOException      If an I/O error occurs.
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Inform the client that GET requests are not supported for this servlet
        response.getWriter().append("GET method is not supported for this operation.");
    }

    /**
     * Handles the POST request to add a reply to a specific comment.
     * 
     * @param request  The HttpServletRequest object that contains the request the client made to the servlet.
     * @param response The HttpServletResponse object that contains the response the servlet returns to the client.
     * @throws ServletException If a servlet-specific error occurs.
     * @throws IOException      If an I/O error occurs.
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Extract parameters from the request
        int commentId = Integer.parseInt(request.getParameter("commentId")); // Get the comment ID from the request
        String replyContent = request.getParameter("replyContent"); // Get the reply content from the request
        int userId = (Integer) request.getSession().getAttribute("userId"); // Get the user ID from the session

        // Create a new Reply object and set its properties
        Reply reply = new Reply();
        reply.setCommentID(commentId); // Set the comment ID for the reply
        reply.setUserID(userId); // Set the user ID for the reply
        reply.setReplyText(replyContent); // Set the content of the reply

        // Use CommentDAO to add the reply to the database
        CommentDAO commentDAO = new CommentDAO();
        commentDAO.addReply(reply); // Call the DAO method to add the reply

        // Redirect back to the topic details page
        int topicId = commentDAO.getTopicIdByCommentId(commentId); // Get the topic ID by the comment ID
        response.sendRedirect("topicDetails.jsp?topicId=" + topicId); // Redirect to the topic details page with the topic ID
    }
}
