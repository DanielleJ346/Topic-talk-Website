package controller;

import dao.CommentDAO; // Import the DAO class for managing comments
//import dao.TopicDAO; // Import for managing topics
import model.Comment; // Import the Comment model class

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
//import java.sql.Timestamp;
//import java.util.Date;

/**
 * Servlet implementation class AddCommentServlet
 * Handles the addition of new comments to a topic.
 */
@WebServlet("/AddCommentServlet")
public class AddCommentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    /**
     * Default constructor
     */
    public AddCommentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * Handles GET requests.
     * GET requests are typically not used for adding comments, so this method returns a message indicating that the GET method is not supported.
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Typically, GET requests are not used for adding comments, so we could either redirect or show an error.
    	// Inform the client that GET requests are not supported for this servlet
        response.getWriter().append("GET method is not supported for this operation.");
    }

    /**
     * Handles POST requests.
     * This method processes the addition of a new comment.
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Extract parameters from the request
        int topicId = Integer.parseInt(request.getParameter("topicId")); // Get the topic ID from the request
        String commentContent = request.getParameter("commentContent"); // Get the comment content from the request
        int userId = (Integer) request.getSession().getAttribute("userId"); // Get the user ID from the session

        // Create a new Comment object and set its properties
        Comment comment = new Comment();
        comment.setCommentID(topicId); // Set the topic ID for the comment
        comment.setCommentID(userId); // Set the user ID for the comment
        comment.setContent(commentContent); // Set the content of the comment
        //comment.setTimestamp(new Timestamp(new Date().getTime()));

        // Use CommentDAO to add the comment to the database
        CommentDAO commentDAO = new CommentDAO();
        commentDAO.addComment(comment);

        // Redirect back to the topic details page
        response.sendRedirect("topicDetails.jsp?topicId=" + topicId);
    }
}


