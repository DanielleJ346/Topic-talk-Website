package dao;

import java.util.List;

/**
 * The {@code Comment} class represents a comment made on a specific topic 
 * within the application. It contains information about the topic ID the comment 
 * is associated with, the user ID of the person who made the comment, and the text 
 * content of the comment. Additionally, the class allows setting and retrieving replies 
 * to the comment.
 */

public class Comment {
    private int topicID; // The ID of the topic that this comment is associated with.
    private int userID; // The ID of the user who made the comment.
    private String commentText; // The text content of the comment.
    private List<Reply> replies; // The list of replies associated with this comment.

    /**
     * Getter for topicID:
     * Gets the ID of the topic that this comment is associated with.
     *
     * @return the ID of the topic
     */
    public int getTopicID() {
        return topicID;
    }
    
    /**
     * Setter for topicID:
     * Sets the ID of the topic that this comment is associated with.
     *
     * @param topicID the ID of the topic
     */
    public void setTopicID(int topicID) {
        this.topicID = topicID;
    }

    
    /**
     * Getter for userID:
     * Gets the ID of the user who made the comment.
     *
     * @return the ID of the user
     */
    public int getUserID() {
        return userID;
    }
    
    
    /**
     * Setter for userID:
     * Sets the ID of the user who made the comment.
     *
     * @param userID the ID of the user
     */
    public void setUserID(int userID) {
        this.userID = userID;
    }
    
     
    /**
     * Getter for commentText:
     * Gets the text content of the comment.
     *
     * @return the text content of the comment
     */
    public String getCommentText() {
        return commentText;
    }

    /**
     * Setter for commentText:
     * Sets the text content of the comment.
     *
     * @param commentText the text content of the comment
     */
    public void setCommentText(String commentText) {
        this.commentText = commentText;
    }

     /**
     * Getter for replies:
     * Gets the list of replies associated with this comment.
     *
     * @return a list of {@code Reply} objects representing replies to this comment
     */
    public List<Reply> getReplies() {
        return replies;
    }
    

    /**
     * Setter for replies: 
     * Sets the list of replies associated with this comment.
     *
     * @param replies a list of {@code Reply} objects representing replies to this comment
     */
    public void setReplies(List<Reply> replies) {
        this.replies = replies;
    }
}
