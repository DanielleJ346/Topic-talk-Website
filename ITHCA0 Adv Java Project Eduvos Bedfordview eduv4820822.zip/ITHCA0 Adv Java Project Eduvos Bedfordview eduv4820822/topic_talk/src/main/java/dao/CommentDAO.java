package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Comment;
// import model.Reply;
import topictalk.util.DatabaseConnection;

/**
 * Data Access Object (DAO) class for performing database operations 
 * related to comments and replies in the TopicTalk application.
 */

public class CommentDAO {
	/**
     * This method establishes a connection to the database using a utility class.
     *
     * @return Connection to the database
     * @throws SQLException if a database access error occurs
     * @throws ClassNotFoundException if the database driver class is not found
     */
    private Connection getConnection() throws SQLException, ClassNotFoundException {
        return DatabaseConnection.initializeDatabase(); 
    }

    /**
     * This method adds a new comment to the database.
     *
     * @param comment The Comment object containing the details of the comment
     */
    public void addComment(Comment comment) {
        String sql = "INSERT INTO comment (topicID, userID, commentText) VALUES (?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, comment.getTopicID());
            stmt.setInt(2, comment.getUserID());
            stmt.setString(3, comment.getCommentText());
            stmt.executeUpdate();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    /**
     * Method to add a reply to a specific comment in the database.
     *
     * @param reply The Reply object containing the details of the reply
     */
    public void addReply(dao.Reply reply) {
        String sql = "INSERT INTO reply (commentID, userID, replyText) VALUES (?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, reply.getCommentID());
            stmt.setInt(2, reply.getUserID());
            stmt.setString(3, reply.getReplyText());
            stmt.executeUpdate();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    /**
     * Method to retrieve the topic ID associated with a specific comment ID.
     *
     * @param commentID The ID of the comment
     * @return The ID of the topic associated with the comment, 
     *         or -1 if no matching topic ID is found
     */
    public int getTopicIdByCommentId(int commentID) {
        String sql = "SELECT topicID FROM comment WHERE id = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, commentID);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("topicID");
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return -1; // Return a default or error value if the query fails
    }


    /**
     * Method to retrieve a list of comments associated with a specific topic ID.
     *
     * @param topicID The ID of the topic
     * @return A list of Comment objects associated with the specified topic
     */
    public List<Comment> getCommentsByTopicID(int topicID) {
        List<Comment> comments = new ArrayList<>();
        String sql = "SELECT * FROM comment WHERE topicID = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, topicID);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Comment comment = new Comment();
                comment.setCommentID(rs.getInt("id"));
                comment.setTopicID(rs.getInt("topicID"));
                comment.setUserID(rs.getInt("userID"));
                comment.setCommentText(rs.getString("commentText"));
                comments.add(comment);
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return comments;
    }
}
