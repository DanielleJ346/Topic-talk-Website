package dao;

/**
 * The {@code Reply} class represents a reply to a comment in the application.
 * It contains information about the reply such as the comment ID it is associated with,
 * the user ID of the person who made the reply, the text of the reply, the replier's name,
 * and the content of the reply.
 */

public class Reply {
    private int commentID; // The ID of the comment to which this reply is associated.
    private int userID; // The ID of the user who made the reply.
    private String replyText; // The text content of the reply.
    private String replierName; // The name of the user who made the reply.The name of the user who made the reply.
    private String content; // The content of the reply.     

    
    /**
     * Getter for commentID:
     * Gets the ID of the comment to which this reply is associated.
     *
     * @return the ID of the comment
     */
    public int getCommentID() {
        return commentID;
    }

     
    /**
     * Setter for commentID:
     * Sets the ID of the comment to which this reply is associated.
     *
     * @param commentID the ID of the comment
     */
    public void setCommentID(int commentID) {
        this.commentID = commentID;
    }

    
    /**
     * Getter for userID:
     * Gets the ID of the user who made the reply.
     *
     * @return the ID of the user
     */
    public int getUserID() {
        return userID;
    }
    
     
    /**
     * Setter for userID:
     * Sets the ID of the user who made the reply.
     *
     * @param userID the ID of the user
     */
    public void setUserID(int userID) {
        this.userID = userID;
    }

    
    
    /**
     * Getter for replyText:
     * Gets the text content of the reply.
     *
     * @return the text content of the reply
     */
    public String getReplyText() {
        return replyText;
    }
    
     
    /**
     * Setter for replyText:
     * Sets the text content of the reply.
     *
     * @param replyText the text content of the reply
     */
    public void setReplyText(String replyText) {
        this.replyText = replyText;
    }


  
    /**
     * Getter for replierName:
     * Gets the name of the user who made the reply.
     *
     * @return the name of the replier
     */
    public String getReplierName() {
        return replierName;
    }

    
    /**
     * Setter for replierName:
     * Sets the name of the user who made the reply.
     *
     * @param replierName the name of the replier
     */
    public void setReplierName(String replierName) {
        this.replierName = replierName;
    }

    
    /**
     * Getter for content:
     * Gets the content of the reply.
     *
     * @return the content of the reply
     */
    public String getContent() {
        return content;
    }

    
    /**
     * Setter for content:
     * Sets the content of the reply.
     *
     * @param content the content of the reply
     */
    public void setContent(String content) {
        this.content = content;
    }
}
