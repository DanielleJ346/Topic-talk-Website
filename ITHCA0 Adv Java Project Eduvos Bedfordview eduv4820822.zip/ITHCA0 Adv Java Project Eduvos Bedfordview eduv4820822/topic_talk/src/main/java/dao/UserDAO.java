package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.User;
import topictalk.util.DatabaseConnection;

/**
 * Data Access Object (DAO) class for performing database operations 
 * related to users in the TopicTalk application.
 */
public class UserDAO {

    /**
     * Establishes a connection to the database using a utility class.
     *
     * @return Connection to the database
     * @throws SQLException if a database access error occurs
     * @throws ClassNotFoundException if the database driver class is not found
     */
    private Connection getConnection() throws SQLException, ClassNotFoundException {
        return DatabaseConnection.initializeDatabase();
    }

    /**
     * Adds a new user to the database.
     *
     * @param user The User object containing the details of the user
     */
    public void addUser(User user) {
        String sql = "INSERT INTO users (username, password, email, profile_pic) VALUES (?, ?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, user.getUsername());
            stmt.setString(2, user.getPassword());
            stmt.setString(3, user.getEmail());
            stmt.setString(4, user.getProfilePic());
            stmt.executeUpdate();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Retrieves a user from the database by their username.
     *
     * @param username The username of the user
     * @return The User object if found, null otherwise
     
    public User getUserByUsername(String username) {
        String sql = "SELECT * FROM users WHERE username = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                User user = new User();
                user.setId(rs.getInt("id"));
                user.setUsername(rs.getString("username"));
                user.setPassword(rs.getString("password"));
                user.setEmail(rs.getString("email"));
                return user;
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return null; // Return null if user is not found
    }*/

    /**
     * Retrieves a user from the database by their ID.
     *
     * @param userID The ID of the user
     * @return The User object if found, null otherwise
     */
    public User getUserByID(int userID) {
        String sql = "SELECT * FROM users WHERE id = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userID);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                User user = new User();
                user.setId(rs.getInt("id"));
                user.setUsername(rs.getString("username"));
                user.setPassword(rs.getString("password"));
                user.setEmail(rs.getString("email"));
                user.setProfilePic(rs.getString("profile_pic")); // Added field
                return user;
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return null; // Return null if user is not found
    }

    /**
     * Retrieves the profile picture of a user by their ID.
     *
     * @param userID The ID of the user
     * @return The profile picture filename if found, null otherwise
     */
    public String getProfilePic(int userID) {
        String sql = "SELECT profile_pic FROM users WHERE id = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userID);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getString("profile_pic");
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return null; // Return null if profile picture is not found
    }

    /**
     * Updates the user's information in the database.
     *
     * @param user The User object containing the updated user details
     */
    public void updateUser(User user) {
        String sql = "UPDATE users SET username = ?, password = ?, email = ?, profile_pic = ? WHERE id = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, user.getUsername());
            stmt.setString(2, user.getPassword());
            stmt.setString(3, user.getEmail());
            stmt.setString(4, user.getProfilePic());
            stmt.setInt(5, user.getId());
            stmt.executeUpdate();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    /**
     * Deletes a user from the database by their ID.
     *
     * @param userId The ID of the user to delete
     */
    public void deleteUser(int userId) {
        String sql = "DELETE FROM users WHERE id = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            stmt.executeUpdate();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
