package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Topic;
import topictalk.util.DatabaseConnection;

/**
 * Data Access Object (DAO) class for performing database operations 
 * related to topics in the TopicTalk application.
 */
public class TopicDAO {

    /**
     * Establishes a connection to the database using a utility class.
     * 
     * @return A Connection object to the database, or null if the connection fails
     */
    private Connection getConnection() {
        try {
            return DatabaseConnection.initializeDatabase();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Adds a new topic to the database.
     * 
     * @param topic The Topic object containing the details of the new topic
     */
    public void addTopic(Topic topic) {
        String sql = "INSERT INTO topic (userID, topicTitle, topicDesc, topicPic) VALUES (?, ?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, topic.getUserID());
            stmt.setString(2, topic.getTopicTitle());
            stmt.setString(3, topic.getTopicDesc());
            stmt.setString(4, topic.getTopicPic());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Retrieves a topic from the database by its ID.
     * 
     * @param topicID The ID of the topic to be retrieved
     * @return A Topic object containing the details of the retrieved topic, 
     *         or null if the topic is not found
     */
    public Topic getTopicByID(int topicID) {
        String sql = "SELECT * FROM topic WHERE id = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, topicID);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Topic topic = new Topic();
                topic.setId(rs.getInt("id"));
                topic.setUserID(rs.getInt("userID"));
                topic.setTopicTitle(rs.getString("topicTitle"));
                topic.setTopicDesc(rs.getString("topicDesc"));
                topic.setTopicPic(rs.getString("topicPic"));
                return topic;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Retrieves all topics from the database.
     * 
     * @return A list of Topic objects representing all the topics in the database
     */
    public List<Topic> getAllTopics() {
        List<Topic> topics = new ArrayList<>();
        String sql = "SELECT * FROM topic";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Topic topic = new Topic();
                topic.setId(rs.getInt("id"));
                topic.setUserID(rs.getInt("userID"));
                topic.setTopicTitle(rs.getString("topicTitle"));
                topic.setTopicDesc(rs.getString("topicDesc"));
                topic.setTopicPic(rs.getString("topicPic"));
                topics.add(topic);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return topics;
    }

    /**
     * Deletes a topic from the database by its ID.
     * 
     * @param topicID The ID of the topic to be deleted
     */
    public void deleteTopic(int topicID) {
        String sql = "DELETE FROM topic WHERE id = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, topicID);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Creates a new topic in the database.
     * 
     * @param topic The Topic object containing the details of the new topic
     * @return true if the topic was created successfully, false otherwise
     * @throws ClassNotFoundException If the database driver class is not found
     * @throws SQLException If a database access error occurs
     */
    public boolean createTopic(Topic topic) throws ClassNotFoundException, SQLException {
        boolean status = false;
        String query = "INSERT INTO Topics (title, description, topicPic, userID) VALUES (?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.initializeDatabase();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, topic.getTopicTitle());
            stmt.setString(2, topic.getTopicDesc());
            stmt.setString(3, topic.getTopicPic());
            stmt.setInt(4, topic.getUserID());

            int rowsInserted = stmt.executeUpdate();
            if (rowsInserted > 0) {
                status = true;
            }
        }

        return status;
    }
}
